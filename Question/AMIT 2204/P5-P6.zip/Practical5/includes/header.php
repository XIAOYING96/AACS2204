<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!-- Start of header -->
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=8" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <title><?php echo $PAGE_TITLE ?></title>
    </head>
    <body>
        <p>
            [ <a href="list-student.php">List Student</a>
            | <a href="insert-student.php">Insert Student</a>
            ]
        </p>
<!-- End of header -->
