<?php
// Retrieve "tasks" from cookie.
// Explode it from string to array.
// 2022-08-22 8:40am = expired date time
// 2022-08-23 8:40am = current date time

if (isset($_COOKIE["tasks"]))
{   // aaa|bbb|ccc
    // [0] = aaa
    // [1] = bbb
    // [2] = ccc
    $tasks = explode('|', $_COOKIE['tasks']);

    echo "<pre>";
    print_r($tasks);
    echo "</pre>";
}    
// If "task_to_add" is given.
if (isset($_POST['task_to_add']))
{
    // Read string from "task_to_add" input field.
    $task = trim($_POST['task_to_add']);

    // If it is not empty.
    if ($task != null)
    {
        // Santinize it and add it to array.
        $tasks[] = htmlspecialchars($task);
        // Implode it from array to string, use "|" as separator.
        // Store it to cookie, expire after 1 year.
        setcookie('tasks', implode('|', $tasks), time() + 60 * 60 * 24 * 365);
    }
}
// If "task_to_delete" is given.
else if (isset($_POST['task_to_delete']))
{
    // Read the "index" of the array element need to be deleted.
    $key = $_POST['task_to_delete']; // the array index key

    // [0] = henry
    // [1] = ken
    // Remove the particular array element with the specific "index".
    unset($tasks[$key]); // key = 1

    // Re-index the array.
    // [0] = henry

    // [2] = Jia Xin
    $tasks = array_values($tasks);
    // [0] = henry
    // [1] = Jia Xin
    // Implode it from array to string, use "|" as separator.
    // Store it to cookie, expire after 1 year.
    // 8:59am
    setcookie('tasks', implode('|', $tasks), time() + 60 * 60 * 24 * 365);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=8" />
        <title>My To-do List</title>
        <link type="text/css" href="css/style.css" rel="stylesheet" />
    </head>
    <body>
        <h1>My To-do List</h1>
        
        <?php
        if (empty($tasks))
        {
            echo '<p>You do not have any pending task.</p>';
        }
        else
        {
            printf('<p>You have %d pending task(s):</p>', count($tasks));
            echo '<table>';
            foreach ($tasks as $key => $value)
            {
                printf('
                    <tr>
                        <td>
                            <form action="" method="post" style="display:inline">
                                <input type="hidden" name="task_to_delete" value="%d" />
                                <input type="submit" name="delete" value="X" />
                            </form>
                        </td>
                        <td>%d.</td>
                        <td>%s</td>
                    </tr>',
                    $key, $key + 1, $value);
            }
            echo '</table>';
        }
        ?>
        <br />
        <form action="" method="post">
            <input type="text" name="task_to_add" id="task_to_add"
                   size="40" maxlength="50" />
            <input type="submit" name="add" value="Add" />
        </form>
    </body>

    <script type="text/javascript">
        // Just for fun. Please ignore.
        document.getElementById("task_to_add").focus();
    </script>
</html>