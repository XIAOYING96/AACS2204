
<a href="other.php" class="w3-bar-item w3-button">Other Information</a>