<?php

include ("database.php");

if (isset($_GET['delete_m'])){
    
    $delete_id=$_GET ['delete_m'];
    $delete_menu= "delete from menu where menuID ='$delete_id'";
    
    $run_delete= mysqli_query($conn,$delete_menu);
    
    if($run_delete){
        
        echo "<script>alert('Menu has been deleted!')</script>";
        echo "<script>window.open('indexStaff.php?viewMenu','_self')</script>";
    }
}

?>
