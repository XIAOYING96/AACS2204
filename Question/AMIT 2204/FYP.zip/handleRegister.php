<?php 
session_start();
date_default_timezone_set('Asia/Singapore');
require_once("dbcontroller.php");
$db_handle = new DBController();

$conn = $db_handle->connectDB();
$memberName=mysqli_real_escape_string($conn, $_POST['memberName']);
$memberEmail=mysqli_real_escape_string($conn,$_POST['memberEmail']);
$memberPassword=mysqli_real_escape_string($conn,$_POST['memberPassword']);
$memberPhone= mysqli_real_escape_string($conn,$_POST['memberPhone']);
$memberSchool=mysqli_real_escape_string($conn,$_POST['memberSchool']);
//$Cust_Password = md5($password);

   $qr_log = "INSERT INTO member (memberName, memberEmail, memberPassword, memberPhone, memberSchool)
                          VALUES('$memberName','$memberEmail','$memberPassword', '$memberPhone', '$memberSchool')";
   //$done_qr = mysql_query($qr_insert_member);
          
  if (mysqli_query($conn,$qr_log) === TRUE) {
   print "<script language=\"javascript\" type=\"text/javascript\">
   
    window.setTimeout('window.location=\"memberLogin.php\"; ',0);
    
    </script> ";
    echo "<script>alert('Account successfully registered! Congratulations!');</script>";
    
}
else
  {
    echo mysqli_error($conn);
  }

?>
