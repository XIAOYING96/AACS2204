<html>
    <header class="w3-display-container w3-content" style="max-width:100%" style="max-height:50px;">
    <img class="w3-image" src="image/jabatanpelajaran.jpg" alt="Canteen Menus" style="width:100%; min-height: 100px" width="100%" height="50">
</html>