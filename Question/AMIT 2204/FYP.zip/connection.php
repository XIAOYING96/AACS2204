<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$conn = mysqli_connect('localhost', 'root', '', 'fyp', '3306');
if (!$conn) {
    die('Could not connect to MySQL: ' . mysqli_connect_error());
}
 else {
 echo ('');   
 }
 mysqli_query($conn, 'SET NAMES \'utf8\'');
 //TODO: insert your code here.
 mysqli_close($conn);
 
 ?>