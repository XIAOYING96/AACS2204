<?php

include ("database.php");

if (isset($_GET['delete_m'])){
    
    $delete_id=$_GET ['delete_m'];
    $delete_customer= "delete from member where memberID ='$delete_id'";
    
    $run_delete= mysqli_query($conn,$delete_customer);
    
    if($run_delete){
        
        echo "<script>alert('Canteen worker has been deleted!')</script>";
        echo "<script>window.open('indexStaff.php?viewMembers','_self')</script>";
    }
}

?>
