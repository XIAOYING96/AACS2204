<?php
session_start();
 
if (!empty($_SESSION['staffUsername'])) {
    header('location:index.php');
}
?>

<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Canteen Workers Login</title>
<meta name="description" content=""/>
<meta name="keywords" content=""/>
<meta charset="UTF-8">
<link href="css/style2.css" rel="stylesheet" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<body>
        <div class="w3-container w3-center w3-display-middle w3-padding-32 w3-margin-center " >
	<h1><font color="white">Canteen Workers Register</font></h1>
        
            
            <div id="register" class="animate form">
        
            <form  action="handleRegister.php" method ='post' autocomplete="on"> 
                <TABLE align="center" >
                    <TR>
                        <B><font color="white">Name </font></B><INPUT type="text" name="memberName" size="40" placeholder="Example: Hamzah bin Ali" required/><P></P>
                        <B><font color="white">Email </font></B><INPUT type="text" name="memberEmail" size="40" placeholder="Example : abcd123@gmail.com" required/><P></P>
                        <B><font color="white">Password</font></B><INPUT type="text" name="memberPassword" size="40" placeholder="Example : abcd1234" required/><P></P>
                        <B><font color="white">Phone Number</font></B><INPUT type="text" name="memberPhone" size="40" placeholder="Example : 0123456789" required/><P></P>
                        <B><font color="white">School's Name Contributed</font></B><INPUT type="text" name="memberSchool" size="40" placeholder="Example : SK Taman Anggerik" required/><P></P>
                    </TR>
                    <P></P>
                    <INPUT type="submit" name="insert_post" value="Register"/></TD>          
                </TABLE>
            </form>        
            </div>
        </div>
</body>
</html>