<?php 
session_start();
date_default_timezone_set('Asia/Singapore');
include ("connection.php");

$adminEmail=$_POST['memberEmail'];
echo $adminEmailemail;
$adminPassword = $_POST['adminPassword'];

//echo $cust_email;
//echo $cust_pwd;
$cryptpass = $adminPassword;

$qr_log = "SELECT * FROM admin WHERE adminEmail = '$adminEmail'";
$result = mysqli_query($conn, $qr_log);
$row = mysqli_fetch_assoc($result);
$detect_log = mysqli_num_rows($result);

if($detect_log == 0)
{
	print "<script language=\"javascript\" type=\"text/javascript\">
	<!--
	window.setTimeout('window.location=\"index.php\"; ',0);
	//-->
	</script> ";
	echo "<script>alert('User did not register yet or incorrect username. Please contact our customer service.');</script>";
	//echo $modul;
}
else
{
	$qr_log1 = "SELECT * FROM admin WHERE adminEmail = '$adminEmail'";
	$result1 = mysqli_query($conn, $qr_log1);
        $row1 = mysqli_fetch_assoc($result1);
	$get_pwd1 = $row1['adminPassword'];
	$get_name1 = $row1['adminName'];
	$get_id1 = $row1['adminEmail'];
	
	if($cryptpass !== $get_pwd1)
	{
		print "<script language=\"javascript\" type=\"text/javascript\">
		<!--
		window.setTimeout('window.location=\"index.php\"; ',0);
		//-->
		</script> ";
		echo "<script type='text/javascript'>alert('Sorry, incorrect password: $get_name1 ');</script>";
	}
	else
	{
		$_SESSION['adminEmail']=$get_id1;
		print "<script language=\"javascript\" type=\"text/javascript\">
		<!--
		window.setTimeout('window.location=\"index.php\"; ',0);
		//-->
		</script> ";
                echo "<script type='text/javascript'>alert('Login succesful: Welcome, $get_name1 ');</script>";
        }
}

?>