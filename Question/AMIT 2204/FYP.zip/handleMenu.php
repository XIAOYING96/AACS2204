<?php
/*include ("connection.php");
include ("database.php");

if(isset($_POST['insert_postMenu']))
{
    
    //getting the text data from the fields for menu table
    $menuName = $_POST['menuName'];
    $menuCat = $_POST['menuCat'];
    $menuImage = $_POST['menuImage'];
    $menuMaxPrice = $_POST['menuMaxPrice'];
    $menuCalory = $_POST['menuCalory'];
    
    //getting the image from the field for menu table
    
    $menuImage=$_FILES['menuImage']['name'];
    $menuImage_tmp = $_FILES['menuImage']['tmp_name'];
    
    move_uploaded_file($menuImage_tmp, "images/$menuImage");
   
    $insert_menu = "insert into menu (menuName, menuCat, menuImage, menuMaxPrice, menuIngredient, menuCalory)"
            . "values ('$menuName','$menuCat','$menuImage','$menuMaxPrice', '$menuCalory')";
   
    $insert_menu = mysqli_query($conn, $insert_menu);
  
    if($insert_menu)
        {
            echo "<script>alert('Menu has been inserted!')</script>";
            //echo "<script>window.open('staff_index.php?view_menu','_self')</script>";
        }
}*/

?>

<?php 

session_start();
date_default_timezone_set('Asia/Singapore');
require_once("dbcontroller.php");
$db_handle = new DBController();

$conn = $db_handle->connectDB();

$menuID = mysqli_real_escape_string($conn, $_POST['menuID']);
$menuName = mysqli_real_escape_string($conn, $_POST['menuName']);
$menuCat = mysqli_real_escape_string($conn, $_POST['menuCat']);
$menuMaxPrice = mysqli_real_escape_string($conn, $_POST['menuMaxPrice']);
$menuCalory = mysqli_real_escape_string($conn, $_POST['menuCalory']);
$mainIngredient = mysqli_real_escape_string($conn, $_POST['mainIngredient']);
$sideIngredient = mysqli_real_escape_string($conn, $_POST['sideIngredient']);

$path = 'image/';
$menuImage = basename($_FILES["menuImage"]["name"]);   
$imagepath = $path.$menuImage;
//;

   $qr_log = "INSERT INTO menu (menuID, menuName, menuCat, menuImage, menuMaxPrice, menuCalory, mainIngredient, sideIngredient)"
            . "values ('$menuID','$menuName','$menuCat','$imagepath','$menuMaxPrice', '$menuCalory','$mainIngredient','$sideIngredient')";
   //$done_qr = mysql_query($qr_insert_tblproduct);
          
  if (mysqli_query($conn,$qr_log) === TRUE) {
   print "<script language=\"javascript\" type=\"text/javascript\">
    
    window.setTimeout('window.location=\"indexStaff.php?viewMenu\"; ',0);
    
    </script> ";
    echo "<script>alert('Menu successfully inserted !');</script>";
    
}
else
  {
    echo mysqli_error($conn);
  }

?>
