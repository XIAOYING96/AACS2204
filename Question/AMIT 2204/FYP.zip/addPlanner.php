<?php

// Connexion à la base de données
require_once('database.php');
//echo $_POST['plannerDate'];
if (isset($_POST['plannerDate']) && isset($_POST['plannerBreakfast']) && isset($_POST['plannerLunch']) && isset($_POST['plannerHitea']) && isset($_POST['totalCalories']) && isset($_POST['plannerColor'])){
	
	$plannerDate = $_POST['plannerDate'];
	$plannerBreakfast = $_POST['plannerBreakfast'];
	$plannerLunch = $_POST['plannerLunch'];
        $plannerHitea = $_POST['plannerHitea'];
        $totalCalories = $_POST['totalCalories'];
	$plannerColor = $_POST['plannerColor'];

	$sql = "INSERT INTO planner(plannerDate, plannerBreakfast, plannerLunch, plannerHitea, totalCalories, plannerColor) values ('$plannerDate', '$plannerBreakfast', '$plannerLunch', '$totalCalories','$color')";
	//$req = $conn->prepare($sql);
	//$req->execute();
	
	echo $sql;
	
	$query = $conn->prepare( $sql );
	if ($query == false) {
	 print_r($conn->errorInfo());
	 die ('Erreur prepare');
	}
	$sth = $query->execute();
	if ($sth == false) {
	 print_r($query->errorInfo());
	 die ('Erreur execute');
	}

}
header('Location: '.$_SERVER['HTTP_REFERER']);

	
?>
