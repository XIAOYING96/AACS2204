<!DOCTYPE>
<?php
include("database.php");
?>

<HTML>
    
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Inserting Ingredients</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" href="css/form.css" >
        <style>
        table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 25%;
        }

        td {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
        }

        th {
        border: 1px solid #dddddd;
        text-align: center;
        padding: 8px;
        }

        </style>
    </head>
    
    <body >
        
        <div class="container">
            <table border="1" style="margin-left: 450px;">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Item</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>BH</td>
                        <td>Bihun</td>
                    </tr>
                    <tr>
                        <td>MG</td>
                        <td>Mi Goreng</td>
                    </tr>
                    <tr>
                        <td>M</td>
                        <td>Mi (Other)</td>
                    </tr>
                    <tr>
                        <td>NL</td>
                        <td>Nasi Lemak</td>
                    </tr>
                    <tr>
                        <td>NK</td>
                        <td>Nasi Kerabu</td>
                    </tr>
                    <tr>
                        <td>NG</td>
                        <td>Nasi Goreng</td>
                    </tr>
                    <tr>
                        <td>N</td>
                        <td>Nasi (Other)</td>
                    </tr>
                </tbody>
            </table>

        </div>
        <div class="container">
            <div class="container form-top">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12">
                        <div class="panel panel-danger">
                            <div class="panel-body">
                                <FORM action="handleMenu.php" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label >Menu ID</label>
                                        <input type="text" name="menuID" required  class="form-control" placeholder="Eg : Nl08 "/>
                                    </div>
                                    <div class="form-group">
                                        <label >Menu Name</label>
                                        <p><input type="text" name="menuName" required class="form-control" placeholder="Eg : Nasi Lemak"></p>
                                    </div>
                                    <div class="form-group">
                                        <label >Menu Category</label>
                                            <SELECT name="menuCat" placeholder='Select a category' required>
                                                <option>Select a Category</option>
                                                <OPTION>Breakfast</OPTION>
                                                <OPTION>Lunch</OPTION>
                                                <OPTION>Hi-Tea</OPTION>
                                            </SELECT>
                                    </div>
                                    <div class="form-group">
                                        <label >Menu Image</label>
                                        <input type="file" name="menuImage" required/>
                                    </div>
                                    <div class="form-group">
                                        <label >Suggested Price (in RM)</label>
                                        <p><input type="text" name="menuMaxPrice" class="form-control"  placeholder="Eg : 3.50" required/></p>
                                    </div>
                                    <div class="form-group">
                                        <label >Calories (in kCal)</label>
                                        <p><input type="text" name="menuCalory" class="form-control" placeholder="Eg : 320" required/></p>
                                    </div>
                                    <div class="form-group">
                                        <label >Main Ingredient</label>
                                        <p><input type="text" name="mainIngredient" class="form-control" placeholder="Eg : Ayam" required/></p>
                                    </div>
                                    <div class="form-group">
                                        <label >Side Ingredient</label>
                                        <p><input type="text" name="sideIngredient" class="form-control" placeholder="Eg : Nasi" required/></p>
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-raised btn-lg btn-warning" type="submit" name="insert_post" value="Insert Menu">Insert Menu</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<!-- Add Google Maps -->
<script>
function myMap()
{
  myCenter=new google.maps.LatLng(41.878114, -87.629798);
  var mapOptions= {
    center:myCenter,
    zoom:12, scrollwheel: false, draggable: false,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  var map=new google.maps.Map(document.getElementById("googleMap"),mapOptions);

  var marker = new google.maps.Marker({
    position: myCenter,
  });
  marker.setMap(map);
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu-916DdpKAjTmJNIgngS6HL_kDIKU0aU&callback=myMap"></script>
<!--
To use this code on your website, get a free API key from Google.
Read more at: https://www.w3schools.com/graphics/google_maps_basic.asp
-->

</body>
<?php include ("footerStaff.php");?>
</html>


    
