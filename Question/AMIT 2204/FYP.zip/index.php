<!DOCTYPE html>
<html>
<title>Canteen Menu Recommendation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
body {font-family: "Times New Roman", Georgia, Serif;}
h1,h2,h3,h4,h5,h6 {
    font-family: "Playfair Display";
    letter-spacing: 5px;
}
</style>

<head
    <div class="w3-top">
    <div class="w3-bar w3-blue-gray w3-padding w3-card" style="letter-spacing:4px;">
        <img src="image/MOH Malaysia LOGO.png" style="width:3%; height: 3%;" alt=""/>
        <img src="image/logo kpm.png" style="width:3%; height: 3%;" alt=""/>
        <a href="index.php" class="w3-bar-item w3-button">CAMRES</a>
        <div class="w3-dropdown-hover w3-left">
            <button class="w3-button">Categories</button>
                <div class="w3-dropdown-content w3-bar-block w3-card-4">
                    <a href="breakfast.php" class="w3-bar-item w3-button">Breakfast</a>
                    <a href="lunch.php" class="w3-bar-item w3-button">Lunch</a>
                    <a href="hitea.php" class="w3-bar-item w3-button">Hi-Tea</a>
                </div>
            </div>
        <!-- Right-sided navbar links. Hide them on small screens -->
        <div class="w3-right w3-hide-small">
            <div class="w3-dropdown-hover w3-left">
            <button class="w3-button">Login</button>
                <div class="w3-dropdown-content w3-bar-block w3-card-4">
                    <a href="staffLogin.php" class="w3-bar-item w3-button">KKM Staff</a>
                    <a href="memberLogin.php" class="w3-bar-item w3-button">Canteen Worker</a>
                </div>
            </div>
            <a href="about.php" class="w3-bar-item w3-button">About</a>
            
  </div>
</div>
</head>
    

<!-- Navbar (sit on top) -->


<!-- Header -->
<header class="w3-display-container w3-content w3-wide" style="max-width:1600px;min-width:500px" id="home">
   <?php
        include 'header.php';
    ?>
    
     <div class="w3-display-right w3-padding w3-col l6 m8"  >
        <div class="w3-container w3-center w3-blue-gray">
            <h2>Canteen Menu</h2>
        </div>
        
        <div class="w3-container w3-light-grey w3-padding-16" >
            <div class="search">
            <form class="w3-center"action="function.php" method="get" enctype="multipart/form-data" >
                <div class="w3-row-padding w3-center" style="margin:0 -16px;">
                    <div class="w3-margin-bottom w3-center " style="font-size: large;">
                        <p><label> Main Ingredient </label></p>
                        <p><input class="w3-input w3-border w3-center" style="margin-left: 115px; width: 400px;" type="text" placeholder="Eg : Ayam/ Nasi/ Mi" name="query" required/></p>
                    </div>
                </div>
  
                <input class="w3-button w3-dark-grey" type="submit" name="search" value="search"><i class="fa fa-search w3-margin-right"></i> 
            </form>
        </div>
    </div>
</header>

<!-- Footer -->


</body>
</html>
