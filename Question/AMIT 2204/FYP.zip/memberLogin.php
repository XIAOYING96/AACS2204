<?php
session_start();
 
if (!empty($_SESSION['staffUsername'])) {
    header('location:index.php');
}
?>



<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Canteen Workers Login</title>
<meta name="description" content=""/>
<meta name="keywords" content=""/>
<link href="css/style2.css" rel="stylesheet" type="text/css">

</head>
<body>

	<div class="login">
	<h1>Canteen Workers Login</h1>
            
            <form  action="handleMemberLogin.php" method ='post' autocomplete="on">
                <input type="email" name="memberEmail" placeholder="Email" required="required" />
                <input type="password" name="memberPassword" placeholder="Password" required="required" />
                <button type="submit" value="Login" class="btn btn-primary btn-block btn-large">Sign In.</button>
                <p class="change_link" >
			Not register yet ?
			
                    <a href="memberRegister.php" class="to_register">Register</a>
                </p>    
            </form>
        </div>
</body>
</html>

                
                    
                  