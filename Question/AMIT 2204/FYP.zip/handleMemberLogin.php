<?php 
session_start();
date_default_timezone_set('Asia/Singapore');
include ("connection.php");
require_once("database.php");
global $conn;
$memberEmail=mysqli_real_escape_string($conn, $_POST['memberEmail']);
$memberPassword=mysqli_real_escape_string($conn,$_POST['memberPassword']);



//echo $cust_email;
//echo $cust_pwd;
$cryptpass = $memberPassword;

$qr_log = "SELECT * FROM member WHERE memberEmail = '$memberEmail'";
$result = mysqli_query($conn, $qr_log);
$get_log = mysqli_fetch_assoc($result);
$detect_log = mysqli_num_rows($result);

if($detect_log == 0)
{
	print "<script language=\"javascript\" type=\"text/javascript\">
	<!--
	window.setTimeout('window.location=\"memberLogin.php\"; ',0);
	//-->
	</script> ";
	echo "<script>alert('User did not register yet or incorrect email. Please try again.');</script>";
	//echo $modul;
}
else
{
	$qr_log1 = "SELECT * FROM member WHERE memberEmail = '$memberEmail'";
	$result1 = mysqli_query($conn, $qr_log1);
        $row1 = mysqli_fetch_assoc($result1);
	$get_pwd1 = $row1['memberPassword'];
	$get_name1 = $row1['memberName'];
	$get_id1 = $row1['memberEmail'];
	
	if($cryptpass !== $get_pwd1)
	{
		print "<script language=\"javascript\" type=\"text/javascript\">
		<!--
		window.setTimeout('window.location=\"memberLogin.php\"; ',0);
		//-->
		</script> ";
		echo "<script type='text/javascript'>alert('Sorry, incorrect password: $get_name1 ');</script>";
	}
	else
	{
		$_SESSION['memberEmail']=$get_id1;
		print "<script language=\"javascript\" type=\"text/javascript\">
		<!--
		window.setTimeout('window.location=\"index.php\"; ',0);
		//-->
		</script> ";
                echo "<script type='text/javascript'>alert('Login succesful: Welcome, $get_name1 ');</script>";
        }
}

?>