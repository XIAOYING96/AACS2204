

<html>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 55%;
}

td {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

th {
    border: 1px solid #dddddd;
    text-align: center;
    padding: 8px;
}
body {font-family: "Times New Roman", Georgia, Serif;}
h1,h2,h3,h4,h5,h6 {
    font-family: "Playfair Display";
    letter-spacing: 5px;
}
</style> 

<head
    <div class="w3-top">
    <div class="w3-bar w3-blue-gray w3-padding w3-card" style="letter-spacing:4px;">
        <img src="image/MOH Malaysia LOGO.png" style="width:3%; height: 5.5%;" alt=""/>
        <img src="image/logo kpm.png" style="width:3%; height: 5.5%;" alt=""/>
        <a href="index.php" class="w3-bar-item w3-button">CAMRES</a>
                <div class="w3-dropdown-hover w3-left">
            <button class="w3-button">Categories</button>
                <div class="w3-dropdown-content w3-bar-block w3-card-4">
                    <a href="breakfast.php" class="w3-bar-item w3-button">Breakfast</a>
                    <a href="lunch.php" class="w3-bar-item w3-button">Lunch</a>
                    <a href="hitea.php" class="w3-bar-item w3-button">Hi-Tea</a>
                </div>
            </div>
        <!-- Right-sided navbar links. Hide them on small screens -->
        <div class="w3-right w3-hide-small">
            <div class="w3-dropdown-hover w3-left">
            <button class="w3-button">Login</button>
                <div class="w3-dropdown-content w3-bar-block w3-card-4">
                    <a href="staffLogin.php" class="w3-bar-item w3-button">KKM Staff</a>
                    <a href="memberLogin.php" class="w3-bar-item w3-button">Canteen Worker</a>
                </div>
            </div>
            <a href="about.php" class="w3-bar-item w3-button">About</a>
        </div>
    </div>
</head>

<body>   
           <div class="w3-container w3-light-grey w3-padding-16" >
        <div class="search">
        <table width="800" align="center">
            <tr align="center" >
                <th colspan="8"><h2>View Menu</h2></th>
            </tr>
            <tr align="center" bgcolor="white">
                <th>ID</th>
                <th>Menu Name</th>
                <th>Category</th>
                <th>Image</th>
                <th>Maximum Price Suggestion</th>
                <th>Main Ingredient</th>
                <th>Side Dish</th>
                <th>Calories</th>
            </tr>
       <?php
        include("database.php");
        
        if(isset($_GET['suggestMenu'])){
            $get_menuID2= $_GET['suggestMenu'];
           
            $currentID = preg_replace('#\d.*$#', '', $get_menuID2);
           
            $temp = mysqli_connect('localhost', 'root', '', 'fyp', '3306');
            
                        $raw_results = mysqli_query($temp, "SELECT * FROM menu ");  
                        
                        $tempArray = Array();
                        
                        //$tempArray = mysqli_fetch_array($raw_results);
                        
                        while ($row = mysqli_fetch_array($raw_results)) 
                        {
                              // $tempArray[] =  $row['menuID'];  
                        
                         if(mysqli_num_rows($raw_results)> 0)
                             {
                           // for($x = 0; $x < count($tempArray); $x++)
                           // {
                                $checkID = preg_replace('#\d.*$#', '', $row['menuID']); //trim row ambik alphabet je okayyy ! ambik first huruf je ye.
                                
                                if($currentID == $checkID)
                                {
                            
                                    ?>
            <tr>
                                    <td><?php echo $row['menuID']; ?></td>
                                    <td><?php echo $row['menuName']; ?></td>
                                    <td><?php echo $row['menuCat']; ?></td>
                                    <td><img src="<?php echo $row['menuImage']; ?>" width="70" height="70"/></td>
                                    <td><?php echo $row['menuMaxPrice']; ?></td>
                                    <td><?php echo $row['mainIngredient']; ?></td>
                                    <td><?php echo $row['sideIngredient']; ?></td>
                                    <td><?php echo $row['menuCalory']; ?></td>
            </tr>      
                                 
                                 <?php
                                }
                                }
                            
        }}
?>
            </table>
    </div>
  </div>
</body>

<?php include 'footer.php'; ?>
</html>