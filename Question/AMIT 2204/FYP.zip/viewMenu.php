<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

th {
    border: 1px solid #dddddd;
    text-align: center;
    padding: 8px;
}

</style>

<table width="800" align="center">
    <tr align="center" >    
        <th colspan="8"><h2>View Menu</h2></th>
    </tr>
    <tr align="center" bgcolor="white">
        <th>No</th>
        <th>ID</th>
        <th>Menu Name</th>
        <th>Category</th>
        <th>Image</th>
        <th>Suggestion Price</th>
        <th>Calories</th>
        <th>Main Ingredient</th>
        <th>Side Ingredient</th>
        <th>Edit</th>
        <th>Delete</th>
        
        
        
    </tr>
    <?php
    include ("database.php");
    
    $get_m= "select * from menu";
    
    $run_m= mysqli_query($conn, $get_m);
    
    $i=0;
    
    while($row_m= mysqli_fetch_array($run_m)){
        
        $menuID= $row_m['menuID'];
        $menuName = $row_m['menuName'];
        $menuCat = $row_m['menuCat'];
        $menuImage = $row_m['menuImage'];
        $menuMaxPrice = $row_m['menuMaxPrice'];
        $menuCalory = $row_m['menuCalory'];
        $mainIngredient=$row_m['mainIngredient'];
        $sideIngredient=$row_m['sideIngredient'];
       
        $i++;
    
    
    ?>
    <tr align="center">
        
        <td><?php echo $i; ?></td>
        <td><?php echo $menuID; ?></td>
        <td><?php echo $menuName; ?></td>
        <td><?php echo $menuCat; ?></td>
        <td><img src="<?php echo $menuImage; ?>" width="70" height="70"/></td>
        <td><?php echo $menuMaxPrice; ?></td>
        <td><?php echo $menuCalory; ?></td>
        <td><?php echo $mainIngredient; ?></td>
        <td><?php echo $sideIngredient; ?></td>
        <td><a href="handleEditMenu.php?edit_m=<?php echo $menuID; ?>">Edit</a></td>
        <td><a href="handleDeleteMenu.php?delete_m=<?php echo $menuID; ?>">Delete</a></td>
        
    </tr>
    <?php  }  ?>
    
    
    
    
    
    
    
    
    
</table>
       
