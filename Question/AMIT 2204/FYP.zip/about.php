<!DOCTYPE html>
<html>
    <title>About</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
    <style>
        body{background-image:url("images/jabatanpelajaran.jpg");background-repeat: repeat; background-size: contain;}</style>
    <style>
        body, html {
        height: 100%;
        font-family: "Inconsolata", sans-serif;
        }
        .menu {
            display: none;
        }
    </style>
    
    <header>
    <!-- Navbar (sit on top) -->
        <div class="w3-top">
            <div class="w3-bar w3-blue-gray w3-padding w3-card" style="letter-spacing:4px;">
                <img src="image/MOH Malaysia LOGO.png" style="width:3%; height: 3%;" alt=""/>
                <img src="image/logo kpm.png" style="width:3%; height: 3%;" alt=""/>
                <a href="index.php" class="w3-bar-item w3-button">CAMRES</a>
                <div class="w3-dropdown-hover w3-left">
            <button class="w3-button">Categories</button>
                <div class="w3-dropdown-content w3-bar-block w3-card-4">
                    <a href="breakfast.php" class="w3-bar-item w3-button">Breakfast</a>
                    <a href="lunch.php" class="w3-bar-item w3-button">Lunch</a>
                    <a href="hitea.php" class="w3-bar-item w3-button">Hi-Tea</a>
                </div>
            </div>
                <!-- Right-sided navbar links. Hide them on small screens -->
                <div class="w3-right w3-hide-small">
                    <div class="w3-dropdown-hover w3-left">
                        <button class="w3-button">Login</button>
                            <div class="w3-dropdown-content w3-bar-block w3-card-4">
                                <a href="staffLogin.php" class="w3-bar-item w3-button">KKM Staff</a>
                                <a href="memberLogin.php" class="w3-bar-item w3-button">Canteen Worker</a>
                            </div>  
                    </div>
                    <a href="about.php" class="w3-bar-item w3-button">About</a>
                    <a href="other.php" class="w3-bar-item w3-button">Other Information</a>
                </div>
            </div>
        </div>
    </header>

    <body>
    <!-- Menu Container -->
        <div class="w3-container" id="menu">    
            <div class="w3-content w3-left w3-padding-8" style="max-width:600px; margin: 50px;">
                <img class="mySlides w3-animate-fading" src="image/MOH Malaysia LOGO.png"style="width:600px;">
                <img class="mySlides w3-animate-fading" src="image/logo kpm.png" style="width:620px;">
            </div>
            <div class="w3-content w3-right" style="max-width:600px"> 
                <h5 class="w3-center w3-padding-16"><span class="w3-tag w3-wide">ABOUT</span></h5>  
                    <div class="w3-row w3-center w3-card w3-padding">
                        <a href="javascript:void(0)" onclick="openMenu(event, 'Health');" id="myLink">
                            <div class="w3-col s6 tablink">Ministry of Health</div>
                        </a>
                        <a href="javascript:void(0)" onclick="openMenu(event, 'Education');">
                            <div class="w3-col s6 tablink">Ministry of Education</div>
                        </a>
                    </div>
                    <div id="Health" class="w3-container menu w3-padding-16 w3-card">        
                        <h5>Objective</h5>
                        <p class="w3-text-grey">To assist an individual in achieving and sustaining as well as maintaining a certain level of health status to further facilitate them
                        in leading a productive lifestyle - economically and socially. This could be materialised by introducing or providing a promotional and preventive approaches, other than an efficient treatment 
                        and rehabilitation services, which is suitable and effective, whilst priorities on the less fortunate groups.</p><br>
    
                        <h5>Vision</h5>
                        <p class="w3-text-grey">A nation working together for better health.</p><br>
    
                        <h5>Mission</h5>
                        <p class="w3-text-grey">1. To facilitate and support people to :</p>
                        <ul class="w3-text-grey">
                            <li>attain fully their potential in health</li>
                            <li>appreciate health as a valuable asset</li>
                            <li>take individual responsibility and positive action for their health</li>
                        </ul>
                        <p class="w3-text-grey">2. To ensure a high health system that is :</p>
                        <ul class="w3-text-grey">
                            <li>appreciate health as a valuable asset</li>
                            <li>customer centered</li>
                            <li>equitable</li>
                            <li>affordable</li>
                            <li>technologically appropriate</li>
                            <li>environmentally adaptable</li>
                            <li>innovative</li>
                        </ul>
                        <br>
                    </div>
                    <div id="Education" class="w3-container menu w3-padding-16 w3-card">
                        <h5>Objective</h5>
                        <p class="w3-text-grey">To develop a world class quality education system which will realise the full potential of the individual and fulfill the aspiration of the Malaysian nation.</p><br>  
                        <p class="w3-text-grey">Quality Education Begets Learned Individuals for a Prosperous Nation.</p><br>
    
                        <h5>Mission</h5>
                        <p class="w3-text-grey">Upholding a quality education system that develops individuals to their full potential and fulfills the aspirations of the nation.</p><br>    
                    </div>
            </div>
        </div>


    <!-- Footer -->
    <footer class="w3-center w3-light-grey w3-padding-8 w3-small">
        <p>Nursyafiqah Nadia binti Hassan (2015686374)</p>
        <p>Supervised by Sharifah Nurulhikmah binti Syed Yasin</p>
    </footer>

    <!-- Add Google Maps -->
    <script>
    function myMap()
    {
    myCenter=new google.maps.LatLng(41.878114, -87.629798);
    var mapOptions= {
        center:myCenter,
        zoom:12, scrollwheel: false, draggable: false,
        mapTypeId:google.maps.MapTypeId.ROADMAP
    };
    var map=new google.maps.Map(document.getElementById("googleMap"),mapOptions);

    var marker = new google.maps.Marker({
        position: myCenter,
    });
    marker.setMap(map);
    }

    // Tabbed Menu
    function openMenu(evt, menuName) {
    var i, x, tablinks;
    x = document.getElementsByClassName("menu");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < x.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" w3-dark-grey", "");
    }
    document.getElementById(menuName).style.display = "block";
    evt.currentTarget.firstElementChild.className += " w3-dark-grey";
    }
    document.getElementById("myLink").click();
    </script>
    <script>
    var myIndex = 0;
    carousel();

    function carousel() {
        var i;
        var x = document.getElementsByClassName("mySlides");
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";  
        }
        myIndex++;
        if (myIndex > x.length) {myIndex = 1}    
        x[myIndex-1].style.display = "block";  
        setTimeout(carousel, 9000);    
    }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu-916DdpKAjTmJNIgngS6HL_kDIKU0aU&callback=myMap"></script>
    <!--
    To use this code on your website, get a free API key from Google.
    Read more at: https://www.w3schools.com/graphics/google_maps_basic.asp
    -->

    </body>
</html>
