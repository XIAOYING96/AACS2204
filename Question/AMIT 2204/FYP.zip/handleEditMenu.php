<!DOCTYPE>

<?php

include("database.php");

if(isset($_GET['edit_m'])){
    
    $get_id=$_GET['edit_m'];
    
    $get_menu= "select * from menu where menuID='$get_id'";
    
    $run_menu= mysqli_query($conn, $get_menu);
    
    $i=0;
    
    $row_menu= mysqli_fetch_array($run_menu);
        
        $menuID= $row_menu['menuID'];
        $menuName = $row_menu['menuName'];
        $menuCat = $row_menu['menuCat'];
        $menuImage = $row_menu['menuImage'];
        $menuMaxPrice = $row_menu['menuMaxPrice'];
        $menuCalory = $row_menu['menuCalory'];
        
}
?>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Update Menu</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" href="css/form.css" >
        
    </head> 
    
    <body bgcolor="">
        
       <div class="container">
            <div class="container form-top">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12">
                        <div class="panel panel-danger">
                            <div class="panel-body">
                                <FORM action="" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label >Menu Name</label>
                                        <p><?php echo $menuName;?></p>
                                    </div>
                                    <div class="form-group">
                                        <label >Menu Category</label>
                                        <p><?php echo $menuCat; ?></p>
                                    </div>
                                    <div class="form-group">
                                        <label >Menu Image</label>
                                        <p><?php echo '<img src="'.$menuImage.'"alt="HTML5 Icon" style="width:128px;height:128px"/>'; ?></p>
                                    </div>
                                    <div class="form-group">
                                        <label >Suggested Price (in RM)</label>
                                        <p><input type="text" name="menuMaxPrice" value="<?php echo $menuMaxPrice;?>"/></p>
                                    </div>
                                    <div class="form-group">
                                        <label >Calories (in kCal)</label>
                                        <p><?php echo $menuCalory;?></p>
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-raised btn-lg btn-warning" type="submit" name="update_menu" value="Update Menu">Update Menu</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                
        
        
    </body>   
    
    
    
    
</html>

<?php
if (isset($_POST['update_menu'])){
    
    $update_menuID = $menuID;
    
    $menuMaxPrice=$_POST['menuMaxPrice']; 
    
    
    
    $update_menu="update menu set  menuName ='$menuName',menuCat='$menuCat', menuImage ='$menuImage', menuMaxPrice ='$menuMaxPrice', menuCalory = '$menuCalory' where menuID ='$update_menuID'";
    
    $run_menu= mysqli_query($conn, $update_menu);
    if($run_menu){
    
     echo "<script>alert('Menu has been updated!')</script>";
     echo "<script>window.open('indexStaff.php?viewMenu','_self')</script>";
    } 
}



?>


