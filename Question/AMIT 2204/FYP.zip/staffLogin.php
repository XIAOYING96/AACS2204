<?php
session_start();
 
if (!empty($_SESSION['staffUsername'])) {
    header('location:index.php');
}
?>



<html>
    
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Staff Login</title>
<meta name="description" content=""/>
<meta name="keywords" content=""/>
<link href="css/style2.css" rel="stylesheet" type="text/css">

</head>
<body>

	<div class="login">
	<h1>Staff Login</h1>
            <form  action="handleStaffLogin.php" method ='post' autocomplete="on">
                <input type="email" name="staffEmail" placeholder="Email" required="required" />
                <input type="password" name="staffPassword" placeholder="Password" required="required" />
                <button type="submit" value="Login" class="btn btn-primary btn-block btn-large">Sign In.</button>
            </form>
        </div>
</body>
</html>

