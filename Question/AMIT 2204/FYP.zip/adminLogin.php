<?php
session_start();
 
if (!empty($_SESSION['staffUsername'])) {
    header('location:index.php');
}
?>

<html>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", Arial, Helvetica, sans-serif}
</style>
<body class="w3-light-grey">

<!-- Navigation Bar -->
<div class="w3-bar w3-white w3-large">
    <a href="index.php" class="w3-bar-item w3-button w3-mobile">Canteen Menu System</a>
        <div class="w3-dropdown-hover w3-left">
            
            <button class="w3-button">Login</button>
            
            <div class="w3-dropdown-content w3-bar-block w3-card-4">
                <a href="staffLogin.php" class="w3-bar-item w3-button">KMM Staff</a>
                <a href="adminLogin.php" class="w3-bar-item w3-button">Canteen Admin</a>
                <a href="memberLogin.php" class="w3-bar-item w3-button">Member</a>
            </div>
        </div>
</div>

<!-- Header -->
<header class="w3-display-container w3-content" style="max-width:100%" style="max-height:50px;">
    <img class="w3-image" src="image/food--1200x600.jpg" alt="Canteen Menus" style="width:100%; min-height: 100px" width="100%" height="50">
    <div class="w3-display-middle w3-padding w3-col l6 m8"  >
        <div class="w3-container w3-margin-right w3-center w3-red">
            <h2>Admin Login</h2>
        </div>
        
        <div class="w3-container w3-center w3-white w3-padding-16 w3-margin-right " >
            <div id="login" class="animate form">
                <form  action="handleAdminLogin.php" method ='post' autocomplete="on">  
                    <p> 
                        <input name="adminEmail" type="email" placeholder="Eg : abcd123@gmail.com" style="width : 300px;"/>
                    </p>
                    
                    <p> 
                       <input name="adminPassword" type="password" placeholder="Enter Your Password" style="width : 300px;"/> 
                    </p>
                    
                    <p class="keeplogin"> 
			<input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
			<label for="loginkeeping">Keep me logged in</label>
		    </p>
                    
                    <p class="login button">       
                        <input type="submit" value="Login" /> 
                    </p>
                    
                </form>        
            </div>
        </div>
    </div>
</header>
                

<script>
// Accordion 
function myAccFunc() {
    var x = document.getElementById("demoAcc");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else {
        x.className = x.className.replace(" w3-show", "");
    }
}

// Click on the "Jeans" link on page load to open the accordion for demo purposes
document.getElementById("myBtn").click();


// Script to open and close sidebar
</script>
	</body>
</html>