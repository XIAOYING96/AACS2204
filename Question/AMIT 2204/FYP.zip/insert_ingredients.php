<!DOCTYPE>

<?php
include("connection.php");
include("database.php");
?>

<HTML>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Inserting Ingredients</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" href="css/form.css" >
    </head>
    
    <body >
        <div class="container">
            <div class="container form-top">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12">
                        <div class="panel panel-danger">
                            <div class="panel-body">
                                <FORM action="handleIngredients.php" method="post" enctype="multipart/form-data">
            
                                    <div class="form-group">
                                        <label >Ingredients</label>
                                        <p><input type="text" name="ingredient1" required class="form-control" placeholder="Main Ingredient"></p>
                                        <p><input type="text" name="ingredient2" required class="form-control" placeholder="Second Ingredient"></p>
                                        <p><input type="text" name="ingredient3" required class="form-control" placeholder="Third Ingredient"></p>
                                        <p><input type="text" name="ingredient4" required class="form-control" placeholder="Forth Ingredient"></p>
                                        <p><input type="text" name="ingredient5" required class="form-control" placeholder="Fifth Ingredient"></p>
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-raised btn-lg btn-warning" type="submit" name="insert_post" value="Insert Ingredient">Insert Ingredients</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   



<!-- Add Google Maps -->
<script>
function myMap()
{
  myCenter=new google.maps.LatLng(41.878114, -87.629798);
  var mapOptions= {
    center:myCenter,
    zoom:12, scrollwheel: false, draggable: false,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  var map=new google.maps.Map(document.getElementById("googleMap"),mapOptions);

  var marker = new google.maps.Marker({
    position: myCenter,
  });
  marker.setMap(map);
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu-916DdpKAjTmJNIgngS6HL_kDIKU0aU&callback=myMap"></script>
<!--
To use this code on your website, get a free API key from Google.
Read more at: https://www.w3schools.com/graphics/google_maps_basic.asp
-->

</body>
</html>


    
