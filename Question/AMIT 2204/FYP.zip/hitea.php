<?php
include 'connection.php';
include 'dbcontroller.php';
?>

<html>
<title>Canteen Menu Recommendation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	
	<!-- FullCalendar -->
	<link href='css/fullcalendar.css' rel='stylesheet' />
<style>
    #calendar {
		max-width: 800px;
	}
	.col-centered{
		float: none;
		margin: 0 auto;
	}
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 55%;
}

td {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

th {
    border: 1px solid #dddddd;
    text-align: center;
    padding: 8px;
}
body {font-family: "Times New Roman", Georgia, Serif;}
h1,h2,h3,h4,h5,h6 {
    font-family: "Playfair Display";
    letter-spacing: 5px;
}

body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}

/* The Close Button */
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
</style>    


<head
    <div class="w3-top">
    <div class="w3-bar w3-blue-gray w3-padding w3-card" style="letter-spacing:4px;">
        <img src="image/MOH Malaysia LOGO.png" style="width:3%; height: 5.5%;" alt=""/>
        <img src="image/logo kpm.png" style="width:3%; height: 5.5%;" alt=""/>
        <a href="index.php" class="w3-bar-item w3-button">CAMRES</a>
        <div class="w3-dropdown-hover w3-left">
            <button class="w3-button">Categories</button>
                <div class="w3-dropdown-content w3-bar-block w3-card-4">
                    <a href="breakfast.php" class="w3-bar-item w3-button">Breakfast</a>
                    <a href="lunch.php" class="w3-bar-item w3-button">Lunch</a>
                    <a href="hitea.php" class="w3-bar-item w3-button">Hi-Tea</a>
                </div>
            </div>
        <!-- Right-sided navbar links. Hide them on small screens -->
        <div class="w3-right w3-hide-small">
            <div class="w3-dropdown-hover w3-left">
            <button class="w3-button">Login</button>
                <div class="w3-dropdown-content w3-bar-block w3-card-4">
                    <a href="staffLogin.php" class="w3-bar-item w3-button">KKM Staff</a>
                    <a href="memberLogin.php" class="w3-bar-item w3-button">Canteen Worker</a>
                </div>
            </div>
            <a href="about.php" class="w3-bar-item w3-button">About</a>
        </div>
    </div>
</head>
<body>
    
    <div class="w3-container w3-light-grey w3-padding-16" >
        <div class="search">
        <table width="1000" align="center">
            <tr align="center" >
                <th colspan="8"><h2>View Menu</h2></th>
            </tr>
            <tr align="center" bgcolor="white">
                <th>ID</th>
                <th>Menu Name</th>
                <th>Category</th>
                <th>Image</th>
                <th>Maximum Price Suggestionb(RM)</th>
                <th>Calories (kCal)</th>
                <th>Suggestion</th>
            </tr>
            
                <?php 
                    
                        $temp = mysqli_connect('localhost', 'root', '', 'fyp', '3306');
                        $raw_results = mysqli_query($temp, "SELECT * FROM menu WHERE menuCat = 'hi-tea'");     
                        
                        if(mysqli_num_rows($raw_results) == 0)
                        {
                            echo"not found $raw_results";
                        }
                        
                        else if(mysqli_num_rows($raw_results)> 0){ // if one or more rows are returned do following  
                                         
                            while($result2=mysqli_fetch_array($raw_results)){
                                // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop     
                ?>
            
            
            
            <tr>
                <td><?php echo $result2['menuID']; ?></td>
                <td><?php echo $result2['menuName']; ?></td>
                <td><?php echo $result2['menuCat']; ?></td>
                <td><img src="<?php echo $result2['menuImage']; ?>" width="70" height="70"/></td>
                <td><?php echo $result2['menuMaxPrice']; ?></td>
                <td><?php echo $result2['menuCalory']; ?></td>
                <td><a href="suggestion.php?suggestMenu=<?php echo $result2['menuID']; ?>">Suggestion</a></td>
            </tr>
        
                
                <?php
                }}?>
            
            <script>
            // Get the modal
            var modal = document.getElementById('myModal');

            // Get the button that opens the modal
            var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close")[0];

            // When the user clicks the button, open the modal 
            btn.onclick = function() {
                modal.style.display = "block";
            }

            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                modal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal) {
                        modal.style.display = "none";
                    }
                }
            </script>   
            
        </table>
        </div> 
    </div>

   
</body>

    
 <?php include 'footer.php'; ?>  

</html>