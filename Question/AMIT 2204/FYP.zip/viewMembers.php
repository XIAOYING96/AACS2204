<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

th {
    border: 1px solid #dddddd;
    text-align: center;
    padding: 8px;
}

</style>

<table width="800" align="center">
    <tr align="center" >    
        <th colspan="8"><h2>View Canteen Workers</h2></th>
    </tr>
    <tr align="center" bgcolor="white">
        <th>No</th>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Phone Number</th>
        <th>School Contributed</th>
        
        
        <th>Delete</th>
        
        
        
    </tr>
    <?php
    include ("database.php");
    
    $get_m= "select * from member";
    
    $run_m= mysqli_query($conn, $get_m);
    
    $i=0;
    
    while($row_m= mysqli_fetch_array($run_m)){
        
        $memberID= $row_m['memberID'];
        $memberName = $row_m['memberName'];
        $memberEmail = $row_m['memberEmail'];
        $memberPassword = $row_m['memberPassword'];
        $memberPhone = $row_m['memberPhone'];
        $memberSchool = $row_m['memberSchool'];
       
        $i++;
    
    
    ?>
    <tr align="center">
        
        <td><?php echo $i; ?></td>
        <td><?php echo $memberID; ?></td>
        <td><?php echo $memberName; ?></td>
        <td><?php echo $memberEmail; ?></td>
        <td><?php echo $memberPassword; ?></td>
        <td><?php echo $memberPhone; ?></td>
        <td><?php echo $memberSchool; ?></td>
        
        <td><a href="handleDeleteMember.php?delete_m=<?php echo $memberID; ?>">Delete</a></td>
        
    </tr>
    <?php  }  ?>
    
    
    
    
    
    
    
    
    
</table>
       
