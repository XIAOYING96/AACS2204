<?php 
session_start();
date_default_timezone_set('Asia/Singapore');
include ("connection.php");
require_once("database.php");
global $conn;
$staffEmail=mysqli_real_escape_string($conn, $_POST['staffEmail']);
$staffPassword=mysqli_real_escape_string($conn,$_POST['staffPassword']);

//echo $cust_email;
//echo $cust_pwd;
$cryptpass = $staffPassword;

$qr_log = "SELECT * FROM staff WHERE staffEmail = '$staffEmail'";
$result = mysqli_query($conn, $qr_log);
$get_log = mysqli_fetch_assoc($result);
$detect_log = mysqli_num_rows($result);


if($detect_log == 0)
{
 print "<script language=\"javascript\" type=\"text/javascript\">
 <!--
 window.setTimeout('window.location=\"StaffLogin.php\"; ',0);
 //-->
 </script> ";
 echo "<script type='text/javascript'>alert('WRONG EMAIL!');</script>";
 //echo $modul;
}
else
{
 $qr_log1 = "SELECT * FROM staff WHERE staffPassword = '$staffPassword'";
 $result1 = mysqli_query($conn, $qr_log1);
 $get_log1 = mysqli_fetch_assoc($result1);
 $get_cus_pw = $get_log1['staffPassword'];
 $get_email = $get_log1['staffEmail'];
 
if($staffPassword !== $get_cus_pw)
  {
    print "<script language=\"javascript\" type=\"text/javascript\">
    <!—
    window.setTimeout('window.location=\"staffLogin.php\"; ',0);
    //-->
    </script> ";
    echo "<script type='text/javascript'>alert('WRONG PASSWORD!');</script>";
    echo mysqli_error();
  }
  else
  {
                $_SESSION['staffEmail'] = $get_email ;
                print "<script language=\"javascript\" type=\"text/javascript\">
    
    window.setTimeout('window.location=\"indexStaff.php?homepage\"; ',0);
    
    </script> ";
    echo "<script type='text/javascript'>alert('Sucessful Login!');</script>";

  }

}

?>