<footer>
    <div class="copyrights">
    	 <p>Nursyafiqah Nadia binti Hassan (2015686374)</p>
         <p>Supervised by Sharifah Nurulhikmah binti Syed</p>
    </div>	
</footer>
