<html>
    <head>
        <script>
            function showCarModel(str)
            {
              
                if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari  
                    xmlhttp=new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function()
                {
                    if (xmlhttp.readyState==4 && xmlhttp.status==200)
                    {
                        console.log(xmlhttp.responseText);
                        document.getElementById("model").innerHTML=xmlhttp.responseText;
                        //  document.getElementById('models').innerHTML = ajax.responseText;
                    }
                }
                xmlhttp.open("GET","getCars.php?q="+str,true);
                xmlhttp.send();
            }
        </script>
    </head>
    <body>
        <form id="carForm" name="carForm">
            <fieldset>
                <legend>Choose Your Car</legend>

                <label for="make">Make:</label>
                <select id="make" onchange="showCarModel(this.value)">
                    <option value="">Select make</option>
                    <option value="Ford">Ford</option>
                    <option value="Honda">Honda</option>
                    <option value="Mazda">Mazda</option>
                </select>
                <br><br>
                <label for="model">Model:</label>
                <select id="model">
                    <option value="">Select model</option>
                </select>
            </fieldset>
        </form>
    </body>