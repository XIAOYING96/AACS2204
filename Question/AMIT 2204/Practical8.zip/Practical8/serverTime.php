<?php
    // current server time (hour:minute:second)
    echo date("H:i:s");
?>